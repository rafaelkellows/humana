<?php
	header("location:http://humanamagna.prd.rm.totvscloud.com.br:2009/Corpore.Net/Login.aspx");
	die();
?>