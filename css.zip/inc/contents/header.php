        <header>
            <h1><a href="./" title="Humana Magna - Excelência no cuidar"><img src="<?php echo $actual_link; ?>images/logoHPositivo.png" border="0" alt="Humana Magna - Excelência no cuidar" /></a></h1>
            <h2>Você tem com quem contar.</h2>
            <p>Fale Conosco: <a href="tel:+551123970229">11 2397 0229</a><a href="<?php echo $actual_link; ?>comochegar.php" title="Como chegar">Como chegar</a></p>
            <nav>
                <a href="http://www.http://www.humanamagna.com.br/news" title="Blog">Blog</a>
                <a href="<?php echo $actual_link; ?>parceiros.php" title="Parceiros">Parceiros</a>
                <a href="<?php echo $actual_link; ?>trabalhe.php" title="Trabalhe Conosco">Trabalhe Conosco</a>
                <div>
                    <span>Acesso Colaborador</span>
                    <div>
                        <a href="http://outlook.humanamagna.com.br" target="_blank" title="Acesse seu e-mail">webmail</a>
                        <a href="http://www.humanamagna.com.br/portalrm" target="_blank" title="Acesse o Portal RM (portal do colaborador)">Portal RM</a>
                    </div>
                </div>
                <ul>
                    <li><a href="mailto:humana@humanamagna.com.br" target="_blank"><i class="fa fa-envelope" aria-hidden="true"></i></a></li>                    
                    <li><a href="https://www.facebook.com/redehumanamagna/" target="_blank"><i class="fa fa-facebook-square" aria-hidden="true"></i></a></li>                    
                    <li><a href="https://www.instagram.com/humanamagna/" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>                    
                    <li><a href="https://www.linkedin.com/company/redehumanamagna/" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>         
                </ul>
            </nav>
            <a href="visita360.php">Faça uma visita <span>360<sup>o</sup></span></a>
        </header>
