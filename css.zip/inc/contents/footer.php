        <footer>
            <h6><a href="./" title="Humana Magna - Excelência no cuidar"><img src="<?php echo $actual_link; ?>images/logoHMedio.png" border="0" alt="Humana Magna - Excelência no cuidar" /></a></h6>
            <address>
                <a href="https://www.google.com.br/maps/place/R.+Verbo+Divino,+1227+-+Ch%C3%A1cara+Santo+Ant%C3%B4nio+(Zona+Sul),+S%C3%A3o+Paulo+-+SP,+04719-002/@-23.6322312,-46.7073934,17z/data=!4m13!1m7!3m6!1s0x94ce50e0444d0f83:0x648f44a0964326fb!2sR.+Verbo+Divino,+1227+-+Ch%C3%A1cara+Santo+Ant%C3%B4nio+(Zona+Sul),+S%C3%A3o+Paulo+-+SP,+04719-002!3b1!8m2!3d-23.6323327!4d-46.7074648!3m4!1s0x94ce50e0444d0f83:0x648f44a0964326fb!8m2!3d-23.6323327!4d-46.7074648" target="_blank">Rua Verbo Divino, 1227 <br>Chácara Santo Antônio <br>CEP 04719-001</a>
                <a class="tel" href="tel:+551123970229">Tel. 11 2397 0229</a>
                <a class="fa" href="mailto:humana@humanamagna.com.br" target="_blank"><i class="fa fa-envelope" aria-hidden="true"></i></a>              
                <a class="fa" href="https://www.linkedin.com/company/redehumanamagna/" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a>                  
            </address>
            <nav>
                <a href="./" title="Home">Home</a>
                <a href="./" title="Home">Blog</a>
                <a href="oquefazemos.php" title="O que fazemos">O que fazemos</a>
                <a href="desospitalizacao.php" title="Processo da desospitalização">Processo da desospitalização</a>
                <a href="conheca.php" title="Quem Somos">Quem Somos</a>
                <a href="nossaestrutura.php" title="Conheça nossa estrutura">Conheça nossa estrutura</a>
                <a href="comoajudar.php" title="Como podemos ajudar">Como podemos ajudar</a>
                <a href="equipe.php" title="A Equipe Humana">A Equipe Humana</a>
                <a href="visita360.php" title="Faça uma visita 360º">Faça uma visita 360<sup>o</sup></a>
                <a href="comochegar.php" title="Como chegar">Como chegar</a>
                <a href="filosofia.php" title="Nossa Filosofia">Nossa Filosofia</a>
                <a href="quemprecisa.php" title="Quem precisa desta assistência">Quem precisa desta assistência</a>
                <a href="parceiros.php" title="Parceiros">Parceiros</a>
                <a href="trabalhe.php" title="Trabalhe Conosco">Trabalhe Conosco</a>
                <a href="http://outlook.humanamagna.com.br" target="_blank" title="Acesse seu e-mail">webmail</a>
                <a href="http://www.humanamagna.com.br/portalrm" target="_blank" title="Acesse o Portal RM (portal do colaborador)">Portal RM</a>
            </nav>
            <a class="powerby" href="http://www.liv360.com.br" target="_blank" title="Powered by Liv 360º">powered by &bull; <span>Liv360<sup>o</sup></span></a>
        </footer>
